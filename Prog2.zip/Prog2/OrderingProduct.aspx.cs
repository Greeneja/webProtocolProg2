﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog1.Prog2
{
    public partial class OrderingProduct : System.Web.UI.Page
    {
        private const double tax = 0.055;

        public double subtotal
        {
            get
            {
                if (Session["subtotal"] == null)
                {
                    Session["subtotal"] = 0;
                }
                return (double)Session["subtotal"];
            }
            set { Session["subtotal"] = value; }
        }

        public double grandTotal
        {
            get {
                if (Session["grandTotal"] != null)
                {
                    return (double)Session["grandTotal"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["grandTotal"] = value; }
        }

        public double taxTotal
        {
            get
            {
                if (Session["taxTotal"] != null)
                {
                    return (double)Session["taxTotal"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["taxTotal"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void btnCompute_Click(object sender, EventArgs e)
        {
            txtID.ReadOnly = true;
            txtPrice.ReadOnly = true;
            txtQuantity.ReadOnly = true;
            subtotal = double.Parse(txtPrice.Text) * double.Parse(txtQuantity.Text);
            txtSubTotal.Text = subtotal.ToString();
            taxTotal = subtotal * tax;
            txtTax.Text = taxTotal.ToString();
            grandTotal = subtotal + taxTotal;
            txtGrandTotal.Text = grandTotal.ToString();
            txtSubTotal.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtSubTotal.Text));
            txtTax.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtTax.Text));
            txtGrandTotal.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtGrandTotal.Text));
            btnReset.Focus();
            
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtID.ReadOnly = false;
            txtPrice.ReadOnly = false;
            txtQuantity.ReadOnly = false;
            txtID.Text = "";
            txtPrice.Text = "";
            txtQuantity.Text = "";
            txtSubTotal.Text = "";
            txtTax.Text = "";
            txtGrandTotal.Text = "";
            txtID.Focus();

        }
    }
}